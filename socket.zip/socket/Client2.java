import java.util.*;
import java.net.*;
import java.io.*;

class Client2{
	public static void main(String[] args) throws Exception
	{
		String ip="127.0.0.1", msg="", read="";
		int port=1234;
		Socket so=new Socket(ip, port);
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(so.getInputStream());
		PrintStream ps=new PrintStream(so.getOutputStream());
		while(!msg.equalsIgnoreCase("end") || !read.equalsIgnoreCase("end"))
		{
			msg=sc.nextLine();
			ps.println(msg);
			read=sc1.nextLine();
			System.out.println(read);
		}
		ps.close();
		sc1.close();
		sc.close();
		so.close();
	}
}