import java.util.*;
import java.net.*;
import java.io.*;

class Server2
{
	public static void main(String[] args) throws Exception
	{
		String msg="", read="";
		int port=1234;
		ServerSocket ss=new ServerSocket(port);
		Socket s=ss.accept();
		Scanner sc1=new Scanner(System.in);
		Scanner sc2=new Scanner(s.getInputStream());
		PrintStream ps=new PrintStream(s.getOutputStream());
		while(!msg.equalsIgnoreCase("end") || read.equalsIgnoreCase("end"))
		{
			read=sc2.nextLine();
			System.out.println(read);
			msg=sc1.nextLine();
			ps.println(msg);
		}
		ps.close();
		sc2.close();
		sc1.close();
		s.close();
		ss.close();
	}
}